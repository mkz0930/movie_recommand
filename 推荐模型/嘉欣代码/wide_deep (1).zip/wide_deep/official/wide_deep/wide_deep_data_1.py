import pandas as pd
import tensorflow as tf

UserID = tf.feature_column.numeric_column("UserID")
ItemID = tf.feature_column.numeric_column("ItemID")
CategoryID = tf.feature_column.numeric_column("CategoryID")
Timestamp = tf.feature_column.numeric_column("Timestamp")
timestamp_buckets = tf.feature_column.bucketized_column(Timestamp,[133333,266666,399999,533332,666665,799998,
                                                                  933331,1066664,1199997,1333330,1466663,1599996,
                                                                  1733329,1866662,1999995])

crossed_columns = [
    tf.feature_column.crossed_column(
        ["UserID", "ItemID","CategoryID"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        ["UserID", "ItemID"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        ["UserID", "ItemID","CategoryID"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        ["UserID", "ItemID","CategoryID","timestamp_buckets"], hash_bucket_size=1000),
    tf.feature_column.crossed_column(
        ["ItemID","CategoryID"], hash_bucket_size=1000)
]

deep_columns = [
    tf.feature_column.embedding_column(UserID, dimension=16),
    tf.feature_column.embedding_column(ItemID, dimension=16),
    tf.feature_column.embedding_column(CategoryID, dimension=16),
    tf.feature_column.embedding_column(Timestamp, dimension=16),
    UserID,
    ItemID,
    CategoryID,
    Timestamp
]

def input_fn(data_file, num_epochs, shuffle):
  """Input builder function."""
  df_data = pd.read_csv(
      tf.gfile.Open(data_file),
      names=title,
      skipinitialspace=True,
      engine="python",
      skiprows=1)
  # remove NaN elements
  df_data = df_data.dropna(how="any", axis=0)
  labels = df_data["Action"]
  return tf.estimator.inputs.pandas_input_fn(
      x=df_data,
      y=labels,
      batch_size=100,
      num_epochs=num_epochs,
      shuffle=shuffle,
      num_threads=5)

m = tf.estimator.DNNLinearCombinedClassifier(
        model_dir="./model_dir",
        linear_feature_columns=crossed_columns,
        dnn_feature_columns=deep_columns,
        dnn_hidden_units=[100, 50])
m.train(
    input_fn=input_fn("train_user_item.csv", num_epochs=None, shuffle=True),
    steps=train_steps)
# set steps to None to run evaluation until all data consumed.
results = m.evaluate(
    input_fn=input_fn("test_user_item.csv", num_epochs=1, shuffle=False),
    steps=None)
print("model directory = %s" % model_dir)
for key in sorted(results):
  print("%s: %s" % (key, results[key]))